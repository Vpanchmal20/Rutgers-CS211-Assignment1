#include<stdio.h>
#include<stdlib.h>



int main(int argc,char**argv)
{
	int i, j, row1, col1, row2, col2;
	FILE *fp=fopen(argv[1],"r");
	if(fp==NULL)
	{
 		return 0;
	}
	fscanf(fp, "%d\t",&row1);
	fscanf(fp, "%d\n",&col1);
	int *array1[row1];
	for(i=0;i<row1;i++)
	{
		array1[i]=(int*)malloc(col1*sizeof(int*));
	}
	for(i = 0;i < row1; i++)
	{
		for(j = 0;j < col1; j++)
		{
			fscanf(fp, "%d\t",&array1[i][j]);
		}	
		fscanf(fp, "\n");
	}
	fscanf(fp, "%d\t",&row2);
	fscanf(fp, "%d\n",&col2);
	int *array2[row2];
	for(i=0;i<row2;i++)
	{
		array2[i]=(int*) malloc(col2*sizeof(int*));
	}
	for( i=0;i<row2;i++)
	{
		for(j=0;j<col2;j++)
		{
			fscanf(fp, "%d\t",&array2[i][j]);
			//anf("%d",&array2[i][j]);
		}
		fscanf(fp, "\n");
	}  
	if(col1 != row2)
	{
		printf("bad-matrices");
		exit('\0');	
	}
	int *sum[row1], res = 0, k;
	for(i=0;i<row1;i++)
	{
		sum[i]=(int*)malloc(col2*sizeof(int*));
	}
	for( i=0; i<row1; ++i)
	{
		for( j=0; j<col2; ++j)
		{
			for( k=0; k<col1; ++k)
			{
				res += array1[i][k]*array2[k][j];
      			}
			sum[i][j] = res;
			res = 0;
		}
	}
	for(i = 0;i < row1; i++)
	{
		for(j = 0; j < col2; j++)
		{
			printf("%d\t", sum[i][j]);
		}
		printf("\n");
	}
	fclose(fp);
	return 0;
}



















