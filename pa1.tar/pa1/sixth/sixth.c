#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void Convert_To_Pig_Latin(char *, int, int);
void Print_to(char *, int, int);
int Is_Vowel(char );

int Is_Vowel(char letter)
{
	if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o'
|| letter == 'u' || letter == 'A' || letter == 'E' || letter == 'I' || letter == 'O' || letter == 'U')
	{
		return 1;
	}
	return 0;
}

int ctr = 0;

void Convert_To_Pig_Latin(char *array, int size, int argc)
{
	int i = 0, j = 0, c = 0, len;
	char *sec, *rest;
	sec = (char*) malloc(size+1);
	rest = (char *) malloc(size + 4);
	if(Is_Vowel(array[0]) == 1)
	{
		strcat(rest, array);
		strcat(rest, "yay");
		len = strlen(rest);
		rest[len+1] = '\0';
		ctr++;
		Print_to(rest, argc, ctr);	
		return;
	}
	else 
	{
		while(Is_Vowel(array[i]) == 0)
		{
			sec[i] = array[i];
			i++;
		}
		len = strlen(sec);
		sec[len+1] = '\0';
		if(Is_Vowel(array[i]) ==  1)
		{
			for(j = i; j < size; j++)
			{	
				rest[c] = array[j];
				c++;
			}
			strcat(rest, sec);
			strcat(rest, "ay");
			ctr++;
			Print_to(rest, argc, ctr);
			return;
		}
	}
}

int main(int argc, char **argv)
{	
	char *ptr;
	int val = argc,i = 1, size;
	while(i < argc)
	{
		size = strlen(argv[i]);
		ptr = (char*) malloc(size+1);
		ptr = argv[i];
		ptr[size] = '\0';
		size += 1;
		Convert_To_Pig_Latin(ptr, size, val);
		i++;		
	}
	return 0;
}

void Print_to(char *arr, int argc, int ctr)
{
	int i = 0, len;	
	char *ptr;
	ptr = arr;
	ctr++;
	len = strlen(arr);
	while(i < len)
	{
		printf("%c", ptr[i]);
		i++;
	}
	if(argc == ctr)
	{
		printf("\n");
		return;
	}
	printf(" ");
	return;
}

