#include <stdlib.h>
#include <stdio.h>

typedef struct node *nodeptr;
typedef struct node
{
	int data;
	nodeptr next;
}node;

nodeptr first = NULL;
int ctr = 0;

nodeptr getnode(int item)
{
	nodeptr temp = (nodeptr)malloc(sizeof(node));
    	temp->data = item;
    	temp->next = first;
	return temp;
}

void Insert_Item(int item)
{
	nodeptr temp = getnode(item), curr = first, prev = first;
    	if(first == NULL)
	{
    	    	first = temp;
    	    	return;
    	}
    	else if (temp->data <= first->data) 
	{
    	    	if(temp->data == first->data)
		{
    	        	return;
    	    	}
    	    	first = temp;
    	    	return;
    	}
    	while(curr)
	{
    	    	if(temp->data == curr->data)
		{
	    	        return;
	    	}
	    	if(temp->data < curr->data)
		{
    	        	prev->next = temp;
    	        	temp->next = curr;
    	        	return;
    	    	}
    	    	prev = curr;
    	    	curr = curr->next;
    	}
    	prev->next = temp;
    	temp->next = NULL;
}	
	
void Delete_Item(int item)
{
    	nodeptr temp = first, prev = first;
    	if(first == NULL)
	{
    	    	return;
    	} 
    	
         if(first->data == item)
	{
                first =first->next;
                temp = first;
                prev = temp;
        }
        while (temp) 
	{
            	if(temp->data != item)
		{
                	prev = temp;
                	temp = temp->next;
            	}	
		else
		{
                    	prev->next = temp->next;
                    	temp = temp->next;
            	}
        }
    	free(temp);
}

void Print_Item()
{
    	nodeptr temp =  first;
    	while(temp)
	{
        	printf("%d\t", temp->data);
        	temp = temp->next;
    	}	
    	printf("\n");
}

int count(nodeptr temp)
{
	int ctr = 0;
	if(temp == NULL)
	{
    		return ctr;
  	}
  	while(temp)
	{
    		ctr++;
    		temp = temp->next;
  	}
  	return ctr;
}

int main(int argc, char **argv)
{
    	FILE *fp = fopen(argv[1], "r");
    	char op;
    	int item;
  	if(fp == NULL)
	{
		printf("error");
        	return 0;
    	}
	if(argc < 2)
	{
		printf("0\n");
		return 0;
	}
	do 
	{
		fscanf(fp, "%c\t%d\n", &op, &item);
		if(op == 'd')
		{
			Delete_Item(item);		
		}
		if(op == 'i')
		{
			Insert_Item(item);

		}
	}while(!feof(fp));
	printf("%d\n", count(first));
	Print_Item();
   
    
    return 0;
}
