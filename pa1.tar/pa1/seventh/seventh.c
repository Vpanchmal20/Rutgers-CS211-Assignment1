#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

int main(int argc, char **argv)
{
	int size, i = 1;
	char res[argc], *sent;
	res[argc-1] = '\0';
	if(argc == '\0')
	{
		return 0;
	}
	do 
	{
		sent = argv[i];
		size = strlen(sent);
		res[i-1] = sent[size-1];
		i++;
	}while(i < argc);
	printf("%s\n", res);
	return 0;
}
