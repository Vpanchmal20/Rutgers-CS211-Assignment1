#include <stdio.h>
#include <stdlib.h>
void Is_Magic(int *, int);

void sum_of_ele(int **mat, int n)
{
	int i, j, sum_r = 0, sum_c = 0, sum_rd = 0, sum_ld = 0, ctr = 0, op = (n*2)+2, val, array[op];
	for(i = 0; i < n; i++)
	{
		sum_r = sum_c = sum_ld = sum_rd = 0;
        	for(j = 0; j < n; j++)
		{
			sum_r += mat[i][j];
			sum_c += mat[j][i];
			if(i == j)
			{
				sum_ld += mat[i][i]; 
			}
			if((i+j) == n-1)
			{
				sum_rd += mat[i][j];			
			}
        	}
        	array[ctr] = sum_r;
		array[ctr+1] = sum_c;
		ctr++;
    	}
	array[ctr] = sum_ld;
	array[ctr] = sum_rd;
    	for(i = 0; i < n; i++)
	{
		val = array[i];
		for(j = 0; j < n-1; j++)
		{
			if(val != array[j])
			{
				printf("not-magic");
				return;
			}
			
		}
	}
	printf("magic");
	return;
}

int main(int argc, char** argv)
{
	int n, i, j, **mat;
	FILE *fp = fopen(argv[1], "r");
	if(fp == NULL)
	{
		return 0;
	}
	fscanf(fp, "%d\n", &n);
	if(n == 1)
	{
		printf("magic");
		exit('\0');
	}
	if(n == 2)
	{
		printf("not-magic");
		return 0;
	}
    	mat = (int**)malloc(n* sizeof(int*));
	for(i = 0; i<n;i++)
	{
        	mat[i] = (int*)malloc(n*sizeof(int));
    	}
	for(i = 0; i<n; i++)
	{
        	for(j = 0; j<n; j++)
		{
			fscanf(fp, "%d\t", &mat[i][j]);
        	}
		fscanf(fp, "\n");
    	}
	sum_of_ele(mat, n);
	fclose(fp);
	return 0;
}
