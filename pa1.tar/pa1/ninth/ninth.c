#include <stdio.h>
#include <stdlib.h>

typedef struct node *nodeptr;

int Search_Item(int);
void Delete_Item(int);

typedef struct node
{
	int data;
	nodeptr lchild;
	nodeptr rchild;
}node;

nodeptr first = NULL;

nodeptr Getnode(int item)
{
	nodeptr temp = (nodeptr)malloc(sizeof(node));
    	temp->data = item;
    	temp->lchild = NULL;
    	temp->rchild= NULL;
	return temp;
}

int Insert_Item(int item)
{
	nodeptr curr = first, prev = NULL;
    	int side = 0;
    	while(curr != NULL)
	{
	        prev = curr;
	        if(curr->data == item)
		{
            		printf("duplicate");
            		return -1;
        	}
        	else if(item < curr->data)
		{
			side = -1;
            		curr = curr->lchild;
        	} 
		else
		{
			side = 1;
            		curr = curr->rchild;
        	}
    	}
	nodeptr temp = Getnode(item);
    	if(prev == NULL)
	{
        	first = temp;
    	}
    	else if(side < 0) 
	{
        	prev->lchild = temp;
    	} 
	else
	{
        	prev->rchild = temp;
    	}
    	printf("inserted");
    	return 1;
}

int Depth_Of_Item(nodeptr temp, int item, int l)
{
    	if(temp == NULL)
	{
        	return 0;
    	}
    	if(item == temp->data)
	{
        	return l;
    	}
    	if(Depth_Of_Item(temp->rchild, item, l++) != 0)
	{
        	return Depth_Of_Item(temp->rchild,item, l);
    	} 	
	else 
	{
	        return Depth_Of_Item(temp->lchild, item, l);
    	}

}


int main(int argc, char** argv) 
{
    	FILE *fp = fopen(argv[1], "r");
    	char ch;
    	int item, valid, i = 1;
    	if(fp == NULL)
	{
        	printf("error\n");
    	}
        do
	{
        	fscanf(fp, "%c\t %d\n", &ch, &item);
		if(ch == 's')
		{
            		valid = Search_Item(item);
            		if(valid == 1)
			{
                		printf(" %d\n", Depth_Of_Item(first, item, i));
            		}
            		if(valid == -1)
			{
                		printf("\n");
            		}
		}
        	if(ch == 'i')
		{
            		valid = Insert_Item(item);
            		if(valid == 1)
			{
                		printf(" %d\n", Depth_Of_Item(first,item, i));
            		}
            		if(valid == -1)
			{
                		printf("\n");
            		}
        	}
		if(ch == 'd')
		{
			Delete_Item(item);
		}
        	
        }while(!feof(fp));
    	return 0;
}
int Search_Item(int item)
{
	nodeptr temp = first;
    	while(temp)
	{
		if(temp->data == item)
		{
			printf("present");
			return 1;
		}		
		else
		{
			if(item < temp->data)
			{
				temp = temp->lchild;			
			}
			else
			{
				temp = temp->rchild;
			}
		}
	}
	printf("absent");
	return -1;
}


void Delete_Item(int item)
{
    	nodeptr curr = first, prev = NULL, temp, new;	
    	if(first == NULL)
	{
    	    	printf("fail\n");
    	    	return;
    	}
	
    	while(curr)
	{
    		if(curr->data == item)	
		{
	    	        break;
	    	}
    	    	prev = curr;
    	    	if(item < curr->data)
		{
	    	        curr = curr->lchild;
    	    	}
		else
		{
    	        	curr = curr->rchild;
    	    	}
    	}
	
    	if(curr == NULL)
	{
    	    	printf("fail\n");
    	    	return;
    	}
    	if(curr->lchild && curr->rchild)	
	{
    	    	temp = curr->rchild;
    	    	while(temp->lchild != NULL)
		{
	    	        prev = temp;
	    	        temp = temp->lchild;
    	    	}
    	    
    	    	curr->data = temp->data;
    	    	temp = temp->rchild;
    	    	prev->lchild = NULL;
    	    	prev->lchild = temp;
    	   	printf("success\n");
    	    	return;
    	}
	
    	if(curr == first)
	{
    	    	if(curr->lchild == NULL)
		{
    	        	first = curr->rchild;
       	    	}	
    	    	else if(curr->rchild == NULL)
		{
	    	       	first = curr->lchild;
    	    	}
    	    	printf("success\n");
    	    	return;
    	}
    	if(curr->rchild)
	{
    	    	new = curr->rchild;
    	} 
	else if(curr->lchild)
	{
    	    new = curr->lchild;
    	}
    	if(curr == prev->lchild)
	{
    	    prev->lchild = new;
    	} 
	else
	{
    	    prev->rchild = new;
    	}
    	printf("success\n");
    	return;
	
}	
	
		
	
	




