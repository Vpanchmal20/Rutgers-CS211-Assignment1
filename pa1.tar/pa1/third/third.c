#include<stdio.h>
#include<stdlib.h>

typedef struct node *nodeptr;
nodeptr Hashtable[10000] = {NULL};
typedef struct node	
{
	int data;
	nodeptr next;
}node;

nodeptr getnode(int item)
{
	nodeptr temp = (nodeptr) malloc(sizeof(node));
	temp->data = item;
	temp->next = NULL;
	return temp;
}

int Hash_Item(int item, int size)
{
	int res = item%size;
	if(res < 0)
	{
		res = abs(res);
		return res;
	}
	else
	{
		return res;
	}
}

void Insert_Item(int item)
{
	nodeptr temp = getnode(item);
	int hash = Hash_Item(item, 10000);

	if(Hashtable[hash] == NULL)
	{
		Hashtable[hash] = temp;
		printf("inserted\n");
		return;
	}
	else
	{
		nodeptr curr = Hashtable[hash], prev = curr;
		while(curr)
		{
			prev = curr;
			curr = curr->next;
			if(prev->data == item)
			{
				printf("duplicate\n");
				return;	
			}			
		}
		prev->next = temp;
		printf("inserted\n");
		return;
	}
	return;
}

int Search_Item(int item)
{
	int val = Hash_Item(item, 10000);
	nodeptr temp = Hashtable[val];
	if(Hashtable[val] == NULL)
	{
		printf("absent\n");
		return -1;
	}
    	while(temp)
	{
		if(temp->data == item)
		{
			printf("present\n");
			return 1;
		}		
		temp = temp->next;
	}
	printf("absent\n");
	return -1;
}

int main(int argc, char **argv)
{
	FILE *fp = fopen(argv[1], "r");
	if(fp == NULL)
	{
		return 0;
	}
	int item;
	char op;
	while(!feof(fp))
	{
		fscanf(fp, "%c\t %d", &op, &item);
		if(op == 's')
		{
			Search_Item(item);
		}
		if(op == 'i')
		{
			Insert_Item(item);
		}
	}
	fclose(fp);
	return 0;
}












